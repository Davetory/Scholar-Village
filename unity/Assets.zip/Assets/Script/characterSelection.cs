using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class characterSelection : MonoBehaviour
{
    public GameObject[] characters;
    public int selected = 0;
    public void selectChar(string gender)
    {
        if (gender == "M")
        {
            selected = 1;
        }
        else
        {
            selected = 0;
        }
        characters[selected].SetActive(true);
    }

    void Start()
    {
        PlayerPrefs.SetInt("selected", selected);
    }
}
